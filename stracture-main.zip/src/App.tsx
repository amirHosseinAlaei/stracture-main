import './App.css'
import ErorLeyout from './assets/leyout/ErorLeyout'
import LandingLeyout from './assets/leyout/LandingLeyout'
import LoginLayout from './assets/leyout/LoginLayout'
import PanleLeyout from './assets/leyout/panleLeyout'
import Login from './pages/login/Login'

function App() {

  return (
   <div>
    <PanleLeyout/>
{/* <LandingLeyout /> */}
{/* <LoginLayout/> */}
{/* <ErorLeyout/> */}

   </div>
  )
}

export default App
