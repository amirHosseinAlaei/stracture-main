
function IndexPanle() {
  return (
    <div>IndexPanle</div>
  )
}

export default IndexPanle