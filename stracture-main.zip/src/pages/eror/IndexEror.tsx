
function IndexEror() {
  return (
    <div>IndexEror</div>
  )
}

export default IndexEror